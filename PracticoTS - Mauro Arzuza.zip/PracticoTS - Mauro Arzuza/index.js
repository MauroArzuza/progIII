// Ejercicio 2
console.log("Ejercicio 2: corriendo desde la consola");
// Ejercicio 3
var texto = "Esto es un string";
var numero = 14;
var booleano = true;
var fecha = new Date(2024, 2, 19);
console.log("String: ".concat(texto, ",\n  Number: ").concat(numero, ",\n  Boolean: ").concat(booleano, ",\n  Date: ").concat(fecha));
// Ejercicio 4
function convertirATexto(numero) {
    return numero.toString();
}
var numeroAConvertir = 10;
console.log("Numero ".concat(numeroAConvertir, " convertido a texto \"").concat(convertirATexto(numeroAConvertir), "\""));
// Ejercicio 5
function sumarNumeros(numeros) {
    var suma = 0;
    numeros.forEach(function (el) {
        suma += el;
    });
    return suma;
}
var array = [1, 10, 40, 3];
console.log("La suma de los elementos del array es: ".concat(sumarNumeros(array)));
var estudiante = {
    nombre: "Ezequiel Argentini",
    edad: 25,
    curso: "Desarrollo Web",
};
var estudianteInfoDiv = document.getElementById("estudianteInfo");
estudianteInfoDiv.innerHTML = "\n  <p>Nombre: ".concat(estudiante.nombre, "</p>\n  <p>Edad: ").concat(estudiante.edad, "</p>\n  <p>Curso: ").concat(estudiante.curso, "</p>\n");
var dir = {
    calle: "Los Aromos 1536",
    ciudad: "Mendoza",
    CP: 5505,
};
var direccionInfoDiv = document.getElementById("direccionInfo");
direccionInfoDiv.innerHTML = "\n<p>Calle: ".concat(dir.calle, ", Ciudad: ").concat(dir.ciudad, ", CP: ").concat(dir.CP, "<p>");
var usu = {
    nombre: "Ezequiel",
    email: "ezeargentini123@gmail.com",
    saludar: function () {
        return "Hola, mi nombre es ".concat(this.nombre);
    },
};
var usuInfoDiv = document.getElementById("emailInfo");
usuInfoDiv.innerHTML = "<p>".concat(usu.saludar(), "<p>");
// Ejercicio 9
var Persona = /** @class */ (function () {
    function Persona(nombre, edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    Persona.prototype.presentarse = function () {
        var contendor = document.getElementById("presentacion");
        if (contendor) {
            contendor.innerHTML = "\n      <p>Hola soy ".concat(this.nombre, " y tengo ").concat(this.edad, " a\u00F1os</p>\n    ");
        }
    };
    return Persona;
}());
var persona = new Persona("Jeronimo Cortez", 21);
persona.presentarse();
// Ejercicio 10
var Caja = /** @class */ (function () {
    function Caja(atributo) {
        this.atributo = atributo;
    }
    Caja.prototype.obtenerDatos = function () {
        var contendor = document.getElementById("caja");
        if (contendor) {
            var parrafo = document.createElement("p");
            parrafo.innerHTML = "\n      <p>Contenido de caja ".concat(this.atributo, "</p>\n    ");
            contendor.appendChild(parrafo);
        }
    };
    return Caja;
}());
var cajaDeTexto = new Caja("Mensaje secreto");
cajaDeTexto.obtenerDatos();
var cajaNumerica = new Caja(1234);
cajaNumerica.obtenerDatos();
// Ejercicio 11
function identidad(valor) {
    return valor;
}
var cajaIdentidad = document.getElementById("identidad");
if (cajaIdentidad) {
    var parrafo = document.createElement("p");
    parrafo.innerHTML = "\n  <p>Identidad numerica: ".concat(identidad(123), "</p>\n  ");
    cajaIdentidad.appendChild(parrafo);
}
if (cajaIdentidad) {
    var parrafo = document.createElement("p");
    parrafo.innerHTML = "\n  <p>Identidad de texto: ".concat(identidad("String"), "</p>\n  ");
    cajaIdentidad.appendChild(parrafo);
}
// Ejercicio 12
var color;
(function (color) {
    color[color["Azul"] = 0] = "Azul";
    color[color["Celeste"] = 1] = "Celeste";
    color[color["Amarillo"] = 2] = "Amarillo";
})(color || (color = {}));
var colorFavorito = color[1];
var cajaColorFavorito = document.getElementById("colorFavorito");
if (cajaColorFavorito) {
    var parrafo = document.createElement("p");
    parrafo.innerHTML = "\n  <p>El color favorito es: ".concat(colorFavorito, "</p>\n  ");
    cajaColorFavorito.appendChild(parrafo);
}
