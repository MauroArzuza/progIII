// Ejercicio 2
console.log("Ejercicio 2: corriendo desde la consola");

// Ejercicio 3
const texto: string = "Esto es un string";
const numero: number = 14;
const booleano: boolean = true;
const fecha: Date = new Date(2024, 2, 19);

console.log(
  `String: ${texto},
  Number: ${numero},
  Boolean: ${booleano},
  Date: ${fecha}`
);

// Ejercicio 4

function convertirATexto(numero: number): string {
  return numero.toString();
}

const numeroAConvertir: number = 10;

console.log(
  `Numero ${numeroAConvertir} convertido a texto "${convertirATexto(
    numeroAConvertir
  )}"`
);

// Ejercicio 5

function sumarNumeros(numeros: number[]): number {
  let suma: number = 0;

  numeros.forEach((el) => {
    suma += el;
  });

  return suma;
}

const array: number[] = [1, 10, 40, 3];

console.log(`La suma de los elementos del array es: ${sumarNumeros(array)}`);

// Ejercicio 6

interface Estudiante {
  nombre: string;
  edad: number;
  curso: string;
}

const estudiante: Estudiante = {
  nombre: "Mauro Arzuza",
  edad: 20,
  curso: "Desarrollo Web",
};

const estudianteInfoDiv = document.getElementById(
  "estudianteInfo"
) as HTMLElement;
estudianteInfoDiv.innerHTML = `
  <p>Nombre: ${estudiante.nombre}</p>
  <p>Edad: ${estudiante.edad}</p>
  <p>Curso: ${estudiante.curso}</p>
`;

// Ejercicio 7
type Direccion = {
  calle: string;
  ciudad: string;
  CP: number;
};

const dir: Direccion = {
  calle: "Los Aromos 1536",
  ciudad: "Mendoza",
  CP: 5505,
};

const direccionInfoDiv = document.getElementById(
  "direccionInfo"
) as HTMLElement;
direccionInfoDiv.innerHTML = `
<p>Calle: ${dir.calle}, Ciudad: ${dir.ciudad}, CP: ${dir.CP}<p>`;

// Ejercicio 8
interface Usuario {
  nombre: string;
  email: string;
  saludar(): string;
}

const usu: Usuario = {
  nombre: "Mauro",
  email: "mauro141@gmail.com",
  saludar(): string {
    return `Hola, mi nombre es ${this.nombre}`;
  },
};

const usuInfoDiv = document.getElementById("emailInfo") as HTMLElement;
usuInfoDiv.innerHTML = `<p>${usu.saludar()}<p>`;

// Ejercicio 9
class Persona {
  nombre: string;
  edad: number;

  constructor(nombre: string, edad: number) {
    this.nombre = nombre;
    this.edad = edad;
  }

  presentarse(): void {
    const contendor: HTMLElement | null =
      document.getElementById("presentacion");
    if (contendor) {
      contendor.innerHTML = `
      <p>Hola soy ${this.nombre} y tengo ${this.edad} años</p>
    `;
    }
  }
}

const persona: Persona = new Persona("Mauro Arzuza", 20);

persona.presentarse();

// Ejercicio 10
class Caja<T> {
  atributo: T;

  constructor(atributo: T) {
    this.atributo = atributo;
  }

  obtenerDatos(): void {
    const contendor: HTMLElement | null = document.getElementById("caja");
    if (contendor) {
      const parrafo: HTMLElement = document.createElement("p");
      parrafo.innerHTML = `
      <p>Contenido de caja ${this.atributo}</p>
    `;

      contendor.appendChild(parrafo);
    }
  }
}

const cajaDeTexto = new Caja<String>("Mensaje secreto");
cajaDeTexto.obtenerDatos();

const cajaNumerica = new Caja<number>(1234);
cajaNumerica.obtenerDatos();

// Ejercicio 11

function identidad<T>(valor: T): T {
  return valor;
}

const cajaIdentidad: HTMLElement | null = document.getElementById("identidad");

if (cajaIdentidad) {
  const parrafo: HTMLElement = document.createElement("p");
  parrafo.innerHTML = `
  <p>Identidad numerica: ${identidad(123)}</p>
  `;
  cajaIdentidad.appendChild(parrafo);
}

if (cajaIdentidad) {
  const parrafo: HTMLElement = document.createElement("p");
  parrafo.innerHTML = `
  <p>Identidad de texto: ${identidad("String")}</p>
  `;
  cajaIdentidad.appendChild(parrafo);
}

// Ejercicio 12
enum color {
  Azul,
  Celeste,
  Amarillo,
}

const colorFavorito = color[1];

const cajaColorFavorito: HTMLElement | null =
  document.getElementById("colorFavorito");

if (cajaColorFavorito) {
  const parrafo: HTMLElement = document.createElement("p");
  parrafo.innerHTML = `
  <p>El color favorito es: ${colorFavorito}</p>
  `;
  cajaColorFavorito.appendChild(parrafo);
}
